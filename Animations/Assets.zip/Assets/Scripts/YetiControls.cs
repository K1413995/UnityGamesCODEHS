using System. Collections;
using System. Collections.Generic;
using UnityEngine;

public class YetiControls : MonoBehaviour {
    public Animator animator;
    public float speed = 10f;

    // Update is called once per frame
    void Update() {
        // Get input values
        float xInput = Input.GetAxis("Horizontal");
        float yInput = Input.GetAxis("Vertical");

        // Create input vector
        Vector2 inputVector = new Vector2(xInput, yInput);

        // Normalize input if magnitude is greater than 1 (diagonal)
        if (inputVector.magnitude > 1) {
            inputVector = inputVector.normalized;
        }

        // Calculate movement with normalized input times speed and deltaTime
        Vector2 movement = inputVector * speed * Time.deltaTime;

        // Move the character
        transform.Translate(movement);

        // Update animator speed parameter based on input magnitude and speed
        animator.SetFloat("Speed", inputVector.magnitude * speed);
    }
}
