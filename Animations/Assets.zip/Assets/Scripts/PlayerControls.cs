using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControls : MonoBehaviour
{
    public float speed = 10f;
    public Rigidbody2D rb2d;

    void Start()
    {
        // Get the Rigidbody2D component attached to this GameObject
        rb2d = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get value of horizontal input
        float xInput = Input.GetAxis("Horizontal") * speed;

        // Get value of vertical input
        float yInput = Mathf.Min(0, Input.GetAxis("Vertical") * speed);

        // Move sprite using Rigidbody2D Component
        rb2d.linearVelocity = new Vector2(xInput, yInput);
    }
}